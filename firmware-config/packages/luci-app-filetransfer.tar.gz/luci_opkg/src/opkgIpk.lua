--[[
LuCI - Lua Configuration Interface

Copyright 2008 Steven Barth <steven@midlink.org>
Copyright 2008-2011 Jo-Philipp Wich <xm@subsignal.org>

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

$Id$
]]--

module("luci.controller.admin.opkgIpk", package.seeall)

function index()
	entry({"admin", "system", "opkg"}, call("opkg_app"), _("install software"), 70)
end

function opkg_app()
	local sys = require "luci.sys"
	local ipk_tmp   = "/tmp/app.ipk"

	local function image_checksum()
		return (luci.sys.exec("md5sum %q" % ipk_tmp):match("^([^%s]+)"))
	end

	local fp=nil
	local save_sta = nil
	luci.http.setfilehandler(
		function(meta, chunk, eof)
			if not fp then
				if meta then
					fp = io.open(ipk_tmp, "w")
				end
			end
			if chunk and fp then
				fp:write(chunk)
			end
			if eof then
				save_sta=1
				fp:close()
			end
		end
	)
	
	if luci.http.formvalue("opkg")  and save_sta==1 then
		local res =luacmd("opkg install "..ipk_tmp)
		if res then
			os.execute("sleep 1 ; rm -f /tmp/app.ipk")
		end
		
		luci.template.render("admin_system/opkg_app", {
			result   = res,
		})
	else
		luci.template.render("admin_system/opkg_app", {
			result   = "",
		})
	end
end

function luacmd(command)
	local fr=io.popen(command ,"r")
	local result = fr:read("*all")
	fr:close()
	result=result:gsub("\n","<br />")
	return result
end

